
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />



$(document).ready(function(){
$('.letest_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.125 9.5C1.125 9.18934 1.37684 8.9375 1.6875 8.9375H14.9545L11.4148 5.39775C11.1951 5.17808 11.1951 4.82192 11.4148 4.60225C11.6344 4.38258 11.9906 4.38258 12.2102 4.60225L16.7102 9.10225C16.9299 9.32192 16.9299 9.67808 16.7102 9.89775L12.2102 14.3977C11.9906 14.6174 11.6344 14.6174 11.4148 14.3977C11.1951 14.1781 11.1951 13.8219 11.4148 13.6023L14.9545 10.0625H1.6875C1.37684 10.0625 1.125 9.81066 1.125 9.5Z" fill="currentColor"></path></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.125 9.5C1.125 9.18934 1.37684 8.9375 1.6875 8.9375H14.9545L11.4148 5.39775C11.1951 5.17808 11.1951 4.82192 11.4148 4.60225C11.6344 4.38258 11.9906 4.38258 12.2102 4.60225L16.7102 9.10225C16.9299 9.32192 16.9299 9.67808 16.7102 9.89775L12.2102 14.3977C11.9906 14.6174 11.6344 14.6174 11.4148 14.3977C11.1951 14.1781 11.1951 13.8219 11.4148 13.6023L14.9545 10.0625H1.6875C1.37684 10.0625 1.125 9.81066 1.125 9.5Z" fill="currentColor"></path></svg></div>',
  slidesToShow: 5,
  slidesToScroll: 1,
  autoplay: true,
  centerMode: false,
  adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1.2,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.2,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    }
  ]
}); 
}); 


// shop by collection slider
$(document).ready(function(){
$('.shop_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.125 9.5C1.125 9.18934 1.37684 8.9375 1.6875 8.9375H14.9545L11.4148 5.39775C11.1951 5.17808 11.1951 4.82192 11.4148 4.60225C11.6344 4.38258 11.9906 4.38258 12.2102 4.60225L16.7102 9.10225C16.9299 9.32192 16.9299 9.67808 16.7102 9.89775L12.2102 14.3977C11.9906 14.6174 11.6344 14.6174 11.4148 14.3977C11.1951 14.1781 11.1951 13.8219 11.4148 13.6023L14.9545 10.0625H1.6875C1.37684 10.0625 1.125 9.81066 1.125 9.5Z" fill="currentColor"></path></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.125 9.5C1.125 9.18934 1.37684 8.9375 1.6875 8.9375H14.9545L11.4148 5.39775C11.1951 5.17808 11.1951 4.82192 11.4148 4.60225C11.6344 4.38258 11.9906 4.38258 12.2102 4.60225L16.7102 9.10225C16.9299 9.32192 16.9299 9.67808 16.7102 9.89775L12.2102 14.3977C11.9906 14.6174 11.6344 14.6174 11.4148 14.3977C11.1951 14.1781 11.1951 13.8219 11.4148 13.6023L14.9545 10.0625H1.6875C1.37684 10.0625 1.125 9.81066 1.125 9.5Z" fill="currentColor"></path></svg></div>',
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  centerMode: false,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: false
      }
    }
  ]
}); 
}); 