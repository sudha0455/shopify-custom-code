$(document).ready(function(){
$('.slide_column').slick({
    arrows: true,
    centerPadding: "0px",
    dots: true,
    slidesToShow: 1,
    infinite: false
});

});