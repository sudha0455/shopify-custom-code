$(document).ready(function(){
$('.Our_curated_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" width="42" height="31" viewBox="0 0 42 31" fill="none"><circle cx="15.1079" cy="15.1079" r="14.6066" transform="matrix(-1 0 0 1 30.2261 0.0581055)" stroke="#CB4047" stroke-width="1.00272"/><path d="M9.68427 15.5205C9.48848 15.3247 9.48848 15.0073 9.68427 14.8115L12.8749 11.6209C13.0707 11.4251 13.3881 11.4251 13.5839 11.6209C13.7797 11.8167 13.7797 12.1341 13.5839 12.3299L10.7478 15.166L13.5839 18.0021C13.7797 18.1979 13.7797 18.5154 13.5839 18.7112C13.3881 18.9069 13.0707 18.9069 12.8749 18.7112L9.68427 15.5205ZM41.6123 15.6674H10.0388V14.6647H41.6123V15.6674Z" fill="#333333"/></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg xmlns="http://www.w3.org/2000/svg" width="43" height="31" viewBox="0 0 43 31" fill="none"><circle cx="27.1066" cy="15.166" r="14.6066" stroke="#CB4047" stroke-width="1.00272"/><path d="M32.5403 15.5205C32.7361 15.3247 32.7361 15.0073 32.5403 14.8115L29.3497 11.6209C29.1539 11.4251 28.8365 11.4251 28.6407 11.6209C28.4449 11.8167 28.4449 12.1341 28.6407 12.3299L31.4768 15.166L28.6407 18.0021C28.4449 18.1979 28.4449 18.5154 28.6407 18.7112C28.8365 18.9069 29.1539 18.9069 29.3497 18.7112L32.5403 15.5205ZM0.612305 15.6674H32.1858V14.6647H0.612305V15.6674Z" fill="#333333"/></svg></div>',
  slidesToShow: 4,
  centerPadding: '10%',
  slidesToScroll: 1,
  autoplay: false,
  centerMode: false,
  adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    }
  ]
});  

 // slider 1
  $('.best_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" width="42" height="31" viewBox="0 0 42 31" fill="none"><circle cx="15.1079" cy="15.1079" r="14.6066" transform="matrix(-1 0 0 1 30.2261 0.0581055)" stroke="#CB4047" stroke-width="1.00272"/><path d="M9.68427 15.5205C9.48848 15.3247 9.48848 15.0073 9.68427 14.8115L12.8749 11.6209C13.0707 11.4251 13.3881 11.4251 13.5839 11.6209C13.7797 11.8167 13.7797 12.1341 13.5839 12.3299L10.7478 15.166L13.5839 18.0021C13.7797 18.1979 13.7797 18.5154 13.5839 18.7112C13.3881 18.9069 13.0707 18.9069 12.8749 18.7112L9.68427 15.5205ZM41.6123 15.6674H10.0388V14.6647H41.6123V15.6674Z" fill="#333333"/></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg xmlns="http://www.w3.org/2000/svg" width="43" height="31" viewBox="0 0 43 31" fill="none"><circle cx="27.1066" cy="15.166" r="14.6066" stroke="#CB4047" stroke-width="1.00272"/><path d="M32.5403 15.5205C32.7361 15.3247 32.7361 15.0073 32.5403 14.8115L29.3497 11.6209C29.1539 11.4251 28.8365 11.4251 28.6407 11.6209C28.4449 11.8167 28.4449 12.1341 28.6407 12.3299L31.4768 15.166L28.6407 18.0021C28.4449 18.1979 28.4449 18.5154 28.6407 18.7112C28.8365 18.9069 29.1539 18.9069 29.3497 18.7112L32.5403 15.5205ZM0.612305 15.6674H32.1858V14.6647H0.612305V15.6674Z" fill="#333333"/></svg></div>',
  slidesToShow: 4.1,
  slidesToScroll: 1,    
  centerPadding: '10%',
  autoplay: false,
  centerMode: false,
  adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    }
  ]
});  


  // slider 2
  $('.feature_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" width="42" height="31" viewBox="0 0 42 31" fill="none"><circle cx="15.1079" cy="15.1079" r="14.6066" transform="matrix(-1 0 0 1 30.2261 0.0581055)" stroke="#CB4047" stroke-width="1.00272"/><path d="M9.68427 15.5205C9.48848 15.3247 9.48848 15.0073 9.68427 14.8115L12.8749 11.6209C13.0707 11.4251 13.3881 11.4251 13.5839 11.6209C13.7797 11.8167 13.7797 12.1341 13.5839 12.3299L10.7478 15.166L13.5839 18.0021C13.7797 18.1979 13.7797 18.5154 13.5839 18.7112C13.3881 18.9069 13.0707 18.9069 12.8749 18.7112L9.68427 15.5205ZM41.6123 15.6674H10.0388V14.6647H41.6123V15.6674Z" fill="#333333"/></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg xmlns="http://www.w3.org/2000/svg" width="43" height="31" viewBox="0 0 43 31" fill="none"><circle cx="27.1066" cy="15.166" r="14.6066" stroke="#CB4047" stroke-width="1.00272"/><path d="M32.5403 15.5205C32.7361 15.3247 32.7361 15.0073 32.5403 14.8115L29.3497 11.6209C29.1539 11.4251 28.8365 11.4251 28.6407 11.6209C28.4449 11.8167 28.4449 12.1341 28.6407 12.3299L31.4768 15.166L28.6407 18.0021C28.4449 18.1979 28.4449 18.5154 28.6407 18.7112C28.8365 18.9069 29.1539 18.9069 29.3497 18.7112L32.5403 15.5205ZM0.612305 15.6674H32.1858V14.6647H0.612305V15.6674Z" fill="#333333"/></svg></div>',
  slidesToShow: 4.1,
  centerPadding: '10%',  
  slidesToScroll: 1,
  autoplay: false,
  centerMode: false,
  adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    }
  ]
});  

  // slider 3
  $('.review_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 400,
  prevArrow: '<div class="slide-arrow-prev"><svg xmlns="http://www.w3.org/2000/svg" width="42" height="31" viewBox="0 0 42 31" fill="none"><circle cx="15.1079" cy="15.1079" r="14.6066" transform="matrix(-1 0 0 1 30.2261 0.0581055)" stroke="#CB4047" stroke-width="1.00272"/><path d="M9.68427 15.5205C9.48848 15.3247 9.48848 15.0073 9.68427 14.8115L12.8749 11.6209C13.0707 11.4251 13.3881 11.4251 13.5839 11.6209C13.7797 11.8167 13.7797 12.1341 13.5839 12.3299L10.7478 15.166L13.5839 18.0021C13.7797 18.1979 13.7797 18.5154 13.5839 18.7112C13.3881 18.9069 13.0707 18.9069 12.8749 18.7112L9.68427 15.5205ZM41.6123 15.6674H10.0388V14.6647H41.6123V15.6674Z" fill="#333333"/></svg></div>',
  nextArrow: '<div class="slide-arrow-next"><svg xmlns="http://www.w3.org/2000/svg" width="43" height="31" viewBox="0 0 43 31" fill="none"><circle cx="27.1066" cy="15.166" r="14.6066" stroke="#CB4047" stroke-width="1.00272"/><path d="M32.5403 15.5205C32.7361 15.3247 32.7361 15.0073 32.5403 14.8115L29.3497 11.6209C29.1539 11.4251 28.8365 11.4251 28.6407 11.6209C28.4449 11.8167 28.4449 12.1341 28.6407 12.3299L31.4768 15.166L28.6407 18.0021C28.4449 18.1979 28.4449 18.5154 28.6407 18.7112C28.8365 18.9069 29.1539 18.9069 29.3497 18.7112L32.5403 15.5205ZM0.612305 15.6674H32.1858V14.6647H0.612305V15.6674Z" fill="#333333"/></svg></div>',
  slidesToShow: 3.1,
  centerPadding: '5%',
  slidesToScroll: 1,
  autoplay: false,
  centerMode: false,
  adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1.1,
        slidesToScroll: 1,
        dots: false,
        arrows:true,
        centerMode: true
      }
    }
  ]
});   

// megamenu  

}); 


